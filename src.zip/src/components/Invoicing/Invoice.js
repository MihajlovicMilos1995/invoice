import React from "react";
import { Space } from "antd";

import CompanyInformationComponent from "./Info/CompanyInformationComponent";
import PartnerInformationComponent from "./Info/PartnerInformationComponent";
import InvoiceInformationComponent from "./Info/InvoiceInformationComponent";
import InvoiceTableComponent from "./Info/InvoiceTableComponent";
import AdditionalInformationComponent from "./Info/AdditionalInformationComponent";

import "../../Styles/Invoice.css";

const Invoice = () => {
  return (
    <div className="invoice-container">
      <InvoiceInformationComponent />

      <div className="company-partner-container">
        <div className="company-information-container">
          <CompanyInformationComponent />
        </div>
        <div className="partner-information-container">
          <PartnerInformationComponent />
        </div>
      </div>

      <hr />

      <div className="table-container">
        <InvoiceTableComponent />
      </div>

      <div className="additional-information-container">
        <AdditionalInformationComponent />
      </div>
    </div>
  );
};

export default Invoice;
