import { Input } from "antd";
import React from "react";

const InvoiceTableComponent = () => {
  return (
    <div>
      <table>
        <thead>
          <tr>
            <th>Naziv usluga</th>
            <th>Obim usluga(kol.)</th>
            <th>Cena</th>
            <th>Vrednost</th>
            <th>Rabat</th>
            <th>Ukupno</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>
              <Input placeholder="Naziv usluge" />
              <Input placeholder="Opis usluge" />
            </td>

            <td>
              <Input placeholder="Kolicina" />
            </td>
            <td>
              <Input placeholder="Cena" />
            </td>
            <td>
              <Input placeholder="Vrednost" />
            </td>
            <td>
              <Input placeholder="Rabat" />
            </td>
            <td>
              <Input placeholder="Ukupno" />
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  );
};

export default InvoiceTableComponent;
