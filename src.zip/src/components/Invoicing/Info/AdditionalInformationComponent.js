import React from "react";
import { Input, Form } from "antd";

const AdditionalInformationComponent = () => {
  return (
    <div className="container">
      <div className="racun-information-container">
        <Form layout="vertical">
          {/* Racun broj */}
          <div className="form-row">
            <div className="form-label">Usluge izvrsio:</div>
            <div className="form-input">
              <Input />
            </div>
          </div>

          {/* Rok placanja */}
          <div className="form-row">
            <div className="form-label">Usluge primio:</div>
            <div className="form-input">
              <Input />
            </div>
          </div>

          {/* Nacin placanja */}
          <div className="form-row">
            <div className="form-label">Nacin placanja:</div>
            <div className="form-input">
              <Input />
            </div>
          </div>
        </Form>
      </div>

      <div className="racun-date-information-container">
        <Form>
          <div className="form=row">
            <div className="form-label">Ukupna vrednost</div>
            <div className="form-input">
              <Input />
            </div>
          </div>
          <div className="form=row">
            <div className="form-label">Uplaceno avansno</div>
            <div className="form-input">
              <Input />
            </div>
          </div>
          <div className="form=row">
            <div className="form-label">Razlika za uplatu</div>
            <div className="form-input">
              <Input />
            </div>
          </div>
        </Form>
      </div>
    </div>
  );
};

export default AdditionalInformationComponent;
